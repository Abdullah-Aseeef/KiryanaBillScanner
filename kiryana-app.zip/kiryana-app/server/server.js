require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const { GoogleGenerativeAI } = require('@google/generative-ai');

const app = express();
app.use(cors());
app.use(express.json());

// ─── MongoDB Models ───────────────────────────────────────────────────────────

const billItemSchema = new mongoose.Schema({
  item: String,
  quantity: Number,
  unit: String,
  price_per_unit: Number,
  total: Number,
});

const billSchema = new mongoose.Schema({
  items: [billItemSchema],
  totalAmount: Number,
  estimatedProfit: Number,
  createdAt: { type: Date, default: Date.now },
});

const Bill = mongoose.model('Bill', billSchema);

// ─── Gemini Client ─────────────────────────────────────────────────────────────

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const GEMINI_SYSTEM = `You are a billing assistant for a Pakistani kiryana (grocery) store.
Your job is to parse an item name, quantity description, and price description into structured JSON.

South Asian unit rules:
- "pao" or "paav" = 0.25 kg
- "aadha kilo" or "half kilo" = 0.5 kg
- "pauna kilo" = 0.75 kg
- "sawa kilo" = 1.25 kg
- "kilo" or "kilogram" or "kg" = 1 kg
- "100 gram" or "ek so gram" = 0.1 kg
- "50 gram" = 0.05 kg
- "dozen" or "darjan" = 12 pieces
- If no unit mentioned, assume unit = "piece" and quantity = number given

Price rules:
- If user says "per kilo", "kilo ka", "rate 1000" => price_per_unit is per kg, total = quantity_in_kg * price_per_unit
- If user says "total", "mila ke", "sab mila ke", or just a number with no "per" => that IS the total. Compute price_per_unit = total / quantity
- If ambiguous, treat the price as the total amount.

Always return ONLY a valid JSON object. No explanation, no markdown, no backticks.
Format: {"item": string, "quantity": number, "unit": string, "price_per_unit": number, "total": number}`;

// ─── Routes ───────────────────────────────────────────────────────────────────

// Parse item via Gemini
app.post('/api/parse', async (req, res) => {
  const { item, qtyRaw, priceRaw } = req.body;
  if (!item || !qtyRaw || !priceRaw) {
    return res.status(400).json({ error: 'item, qtyRaw, and priceRaw are required' });
  }

  try {
    const model = genAI.getGenerativeModel({
      model: 'gemini-1.5-flash',
      systemInstruction: GEMINI_SYSTEM,
    });

    const prompt = `Item: ${item}\nQuantity input: ${qtyRaw}\nPrice input: ${priceRaw}`;
    const result = await model.generateContent(prompt);
    const text = result.response.text().trim();

    // Strip any accidental markdown
    const clean = text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);

    res.json(parsed);
  } catch (err) {
    console.error('Gemini error:', err.message);
    res.status(500).json({ error: 'Failed to parse item. Check your Gemini API key and inputs.' });
  }
});

// Save a completed bill
app.post('/api/bills', async (req, res) => {
  try {
    const { items } = req.body;
    if (!items || !items.length) return res.status(400).json({ error: 'No items provided' });

    const totalAmount = items.reduce((sum, i) => sum + i.total, 0);
    const estimatedProfit = parseFloat((totalAmount * 0.1).toFixed(2));

    const bill = new Bill({ items, totalAmount, estimatedProfit });
    await bill.save();
    res.status(201).json(bill);
  } catch (err) {
    console.error('Save bill error:', err.message);
    res.status(500).json({ error: 'Failed to save bill' });
  }
});

// Get today's bills + dashboard stats
app.get('/api/dashboard', async (req, res) => {
  try {
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    const bills = await Bill.find({ createdAt: { $gte: startOfDay } }).sort({ createdAt: -1 });

    const totalSales = bills.reduce((s, b) => s + b.totalAmount, 0);
    const totalProfit = bills.reduce((s, b) => s + b.estimatedProfit, 0);
    const avgBill = bills.length ? totalSales / bills.length : 0;

    res.json({
      bills,
      stats: {
        totalSales: parseFloat(totalSales.toFixed(2)),
        totalProfit: parseFloat(totalProfit.toFixed(2)),
        billCount: bills.length,
        avgBill: parseFloat(avgBill.toFixed(2)),
      },
    });
  } catch (err) {
    console.error('Dashboard error:', err.message);
    res.status(500).json({ error: 'Failed to fetch dashboard' });
  }
});

// Delete a bill
app.delete('/api/bills/:id', async (req, res) => {
  try {
    await Bill.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete bill' });
  }
});

// ─── Seed Data ────────────────────────────────────────────────────────────────

async function seedIfEmpty() {
  const count = await Bill.countDocuments();
  if (count > 0) return;

  const today = new Date();
  const seedBills = [
    {
      items: [
        { item: 'Aata', quantity: 5, unit: 'kg', price_per_unit: 120, total: 600 },
        { item: 'Cheeni', quantity: 1, unit: 'kg', price_per_unit: 180, total: 180 },
      ],
      totalAmount: 780, estimatedProfit: 78,
      createdAt: new Date(today.setHours(9, 15, 0)),
    },
    {
      items: [
        { item: 'Lipton Chai', quantity: 0.25, unit: 'kg', price_per_unit: 1200, total: 300 },
        { item: 'Doodh', quantity: 2, unit: 'piece', price_per_unit: 160, total: 320 },
        { item: 'Anda', quantity: 12, unit: 'piece', price_per_unit: 20, total: 240 },
      ],
      totalAmount: 860, estimatedProfit: 86,
      createdAt: new Date(today.setHours(10, 30, 0)),
    },
    {
      items: [
        { item: 'Daal Mash', quantity: 0.5, unit: 'kg', price_per_unit: 400, total: 200 },
        { item: 'Tomatoes', quantity: 1, unit: 'kg', price_per_unit: 80, total: 80 },
      ],
      totalAmount: 280, estimatedProfit: 28,
      createdAt: new Date(today.setHours(11, 45, 0)),
    },
    {
      items: [
        { item: 'Basmati Chawal', quantity: 2, unit: 'kg', price_per_unit: 350, total: 700 },
        { item: 'Cooking Oil', quantity: 1, unit: 'piece', price_per_unit: 580, total: 580 },
      ],
      totalAmount: 1280, estimatedProfit: 128,
      createdAt: new Date(today.setHours(12, 10, 0)),
    },
  ];

  await Bill.insertMany(seedBills);
  console.log('✅ Seeded sample daily sales data');
}

// ─── Start ────────────────────────────────────────────────────────────────────

mongoose
  .connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/kiryana')
  .then(async () => {
    console.log('✅ MongoDB connected');
    await seedIfEmpty();
    const PORT = process.env.PORT || 5000;
    app.listen(PORT, () => console.log(`✅ Server running on http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error('❌ MongoDB connection failed:', err.message);
    process.exit(1);
  });
