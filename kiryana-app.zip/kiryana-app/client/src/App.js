import React, { useState } from 'react';
import BillScreen from './components/BillScreen';
import Dashboard from './components/Dashboard';

const STRINGS = {
  en: { tabBill: 'New Bill', tabDash: 'Dashboard', appName: 'Kiryana Assistant', appSub: 'Sales & Profit Tracker' },
  ur: { tabBill: 'نئی رسید', tabDash: 'ڈیش بورڈ', appName: 'کریانہ اسسٹنٹ', appSub: 'سیلز اور منافع ٹریکر' },
};

export default function App() {
  const [lang, setLang] = useState('en');
  const [tab, setTab] = useState('bill');
  const [refreshDash, setRefreshDash] = useState(0);
  const s = STRINGS[lang];
  const isUrdu = lang === 'ur';

  const onBillSaved = () => {
    setRefreshDash(r => r + 1);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center py-4 px-3">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-500 rounded-xl flex items-center justify-center text-white font-bold text-lg shadow-sm">
              K
            </div>
            <div>
              <div className={`font-bold text-gray-900 text-lg leading-tight ${isUrdu ? 'font-urdu' : ''}`}>
                {s.appName}
              </div>
              <div className={`text-xs text-gray-400 ${isUrdu ? 'font-urdu' : ''}`}>{s.appSub}</div>
            </div>
          </div>

          {/* Language Toggle */}
          <div className="flex bg-white border border-gray-200 rounded-full p-1 gap-1 shadow-sm">
            <button
              onClick={() => setLang('en')}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                lang === 'en' ? 'bg-green-500 text-white shadow' : 'text-gray-400 hover:text-gray-700'
              }`}
            >
              EN
            </button>
            <button
              onClick={() => setLang('ur')}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all font-urdu ${
                lang === 'ur' ? 'bg-green-500 text-white shadow' : 'text-gray-400 hover:text-gray-700'
              }`}
            >
              اردو
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex bg-white border border-gray-200 rounded-xl p-1 mb-4 shadow-sm gap-1">
          {['bill', 'dash'].map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${
                tab === t
                  ? 'bg-green-500 text-white shadow'
                  : 'text-gray-400 hover:text-gray-700'
              } ${isUrdu ? 'font-urdu' : ''}`}
            >
              {t === 'bill' ? s.tabBill : s.tabDash}
            </button>
          ))}
        </div>

        {/* Views */}
        {tab === 'bill' ? (
          <BillScreen lang={lang} onBillSaved={onBillSaved} />
        ) : (
          <Dashboard lang={lang} refreshKey={refreshDash} />
        )}
      </div>
    </div>
  );
}
