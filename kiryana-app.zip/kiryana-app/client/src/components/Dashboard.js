import React, { useState, useEffect } from 'react';
import axios from 'axios';

const STRINGS = {
  en: {
    todaySales: "Today's Sales",
    todayProfit: "Today's Profit",
    billsToday: 'Bills Today',
    avgBill: 'Avg Bill',
    recentBills: 'Recent Bills',
    noData: 'No bills yet today.',
    loading: 'Loading...',
    items: 'items',
  },
  ur: {
    todaySales: 'آج کی فروخت',
    todayProfit: 'آج کا منافع',
    billsToday: 'آج کی رسیدیں',
    avgBill: 'اوسط رسید',
    recentBills: 'حالیہ رسیدیں',
    noData: 'آج کوئی رسید نہیں۔',
    loading: 'لوڈ ہو رہا ہے...',
    items: 'اشیاء',
  },
};

function formatTime(dateStr) {
  return new Date(dateStr).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

export default function Dashboard({ lang, refreshKey }) {
  const s = STRINGS[lang];
  const isUrdu = lang === 'ur';
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    axios.get('/api/dashboard')
      .then(r => { setData(r.data); setLoading(false); })
      .catch(() => { setError('Could not connect to server.'); setLoading(false); });
  }, [refreshKey]);

  if (loading) {
    return (
      <div className="bg-white rounded-2xl border border-gray-200 p-8 text-center text-gray-400 shadow-sm">
        <div className="flex gap-1 justify-center mb-2">
          <span className="dot" /><span className="dot" /><span className="dot" />
        </div>
        <div className={`text-sm ${isUrdu ? 'font-urdu' : ''}`}>{s.loading}</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-2xl border border-red-200 p-6 text-center shadow-sm">
        <div className="text-red-400 text-sm">{error}</div>
        <div className="text-xs text-gray-400 mt-1">Make sure the server is running on port 5000.</div>
      </div>
    );
  }

  const { stats, bills } = data;

  const statCards = [
    { label: s.todaySales, value: `Rs. ${Math.round(stats.totalSales).toLocaleString()}`, color: 'text-gray-900' },
    { label: s.todayProfit, value: `Rs. ${Math.round(stats.totalProfit).toLocaleString()}`, color: 'text-green-600' },
    { label: s.billsToday, value: stats.billCount, color: 'text-gray-900' },
    { label: s.avgBill, value: `Rs. ${Math.round(stats.avgBill).toLocaleString()}`, color: 'text-gray-900' },
  ];

  return (
    <div className="flex flex-col gap-3">
      {/* Stat grid */}
      <div className="grid grid-cols-2 gap-3">
        {statCards.map((sc, i) => (
          <div key={i} className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
            <div className={`text-xs text-gray-400 mb-1 ${isUrdu ? 'font-urdu' : ''}`}>{sc.label}</div>
            <div className={`text-xl font-bold ${sc.color}`}>{sc.value}</div>
          </div>
        ))}
      </div>

      {/* Recent bills */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className={`px-4 py-3 border-b border-gray-100 font-semibold text-gray-800 text-sm ${isUrdu ? 'font-urdu' : ''}`}>
          {s.recentBills}
        </div>
        {bills.length === 0 ? (
          <div className={`px-4 py-6 text-center text-sm text-gray-400 ${isUrdu ? 'font-urdu' : ''}`}>{s.noData}</div>
        ) : (
          bills.map(bill => (
            <div key={bill._id} className="flex items-center justify-between px-4 py-3 border-b border-gray-50 last:border-0">
              <div>
                <div className="text-sm text-gray-500">{formatTime(bill.createdAt)}</div>
                <div className="text-xs text-gray-400">{bill.items.length} {s.items}</div>
              </div>
              <div className="text-right">
                <div className="text-sm font-semibold text-gray-900">Rs. {Math.round(bill.totalAmount).toLocaleString()}</div>
                <div className="text-xs text-green-600 font-medium">+Rs. {Math.round(bill.estimatedProfit).toLocaleString()} profit</div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
