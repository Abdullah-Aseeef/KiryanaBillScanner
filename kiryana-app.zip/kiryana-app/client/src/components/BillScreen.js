import React, { useState, useRef, useEffect, useCallback } from 'react';
import axios from 'axios';

const STRINGS = {
  en: {
    currentBill: 'Current Bill',
    estProfit: 'Est. Profit (10%)',
    greetItem: 'What item did the customer ask for?',
    askQty: 'How much? (e.g. 1 pao, aadha kilo, 2 kilo)',
    askPrice: 'What is the price? (e.g. 1000 per kilo, or 50 total)',
    added: (item, qty, unit, total) => `✓ Added: ${item} — ${qty} ${unit} = Rs. ${Math.round(total)}`,
    error: 'Sorry, could not understand. Please try again.',
    saved: '✓ Bill saved! Ready for next customer.',
    total: 'Total',
    profit: 'Profit (10%)',
    nextItem: '+ Next Item',
    saveBill: 'Save Bill',
    tapMic: 'Tap mic to speak, or type below',
    listening: 'Listening... speak now',
    noVoice: 'Voice not supported. Please type.',
    typeHere: 'Type your answer...',
    send: 'Send',
    items: 'Items',
  },
  ur: {
    currentBill: 'موجودہ رسید',
    estProfit: 'متوقع منافع (١٠٪)',
    greetItem: 'گاہک نے کیا مانگا؟',
    askQty: 'کتنا؟ (مثلاً ١ پاؤ، آدھا کلو، ٢ کلو)',
    askPrice: 'قیمت کیا ہے؟ (مثلاً ١٠٠٠ فی کلو، یا ٥٠ کل)',
    added: (item, qty, unit, total) => `✓ شامل: ${item} — ${qty} ${unit} = روپے ${Math.round(total)}`,
    error: 'معذرت، سمجھ نہیں آیا۔ دوبارہ کوشش کریں۔',
    saved: '✓ رسید محفوظ! اگلا گاہک تیار۔',
    total: 'کل',
    profit: 'منافع (١٠٪)',
    nextItem: '+ اگلی چیز',
    saveBill: 'رسید محفوظ کریں',
    tapMic: 'مائیک دبائیں یا نیچے ٹائپ کریں',
    listening: 'سن رہے ہیں... بولیں',
    noVoice: 'آواز سپورٹ نہیں۔ ٹائپ کریں۔',
    typeHere: 'اپنا جواب لکھیں...',
    send: 'بھیجیں',
    items: 'اشیاء',
  },
};

function speak(text, lang) {
  if (!window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const utt = new SpeechSynthesisUtterance(text);
  utt.lang = lang === 'ur' ? 'ur-PK' : 'en-US';
  utt.rate = 0.92;
  window.speechSynthesis.speak(utt);
}

export default function BillScreen({ lang, onBillSaved }) {
  const s = STRINGS[lang];
  const isUrdu = lang === 'ur';

  const [step, setStep] = useState(0); // 0=item, 1=qty, 2=price
  const [currentItem, setCurrentItem] = useState({ item: '', qtyRaw: '', priceRaw: '' });
  const [billItems, setBillItems] = useState([]);
  const [messages, setMessages] = useState([]);
  const [inputVal, setInputVal] = useState('');
  const [loading, setLoading] = useState(false);
  const [listening, setListening] = useState(false);
  const [saving, setSaving] = useState(false);

  const recognitionRef = useRef(null);
  const chatEndRef = useRef(null);
  const inputRef = useRef(null);

  const total = billItems.reduce((sum, i) => sum + i.total, 0);
  const profit = Math.round(total * 0.1);

  const addMsg = useCallback((text, type) => {
    setMessages(prev => [...prev, { text, type, id: Date.now() + Math.random() }]);
  }, []);

  // Initial greeting
  useEffect(() => {
    const msg = s.greetItem;
    setMessages([{ text: msg, type: 'bot', id: 1 }]);
    setTimeout(() => speak(msg, lang), 400);
    // eslint-disable-next-line
  }, []);

  // Auto-scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const botSay = useCallback((text) => {
    addMsg(text, 'bot');
    speak(text, lang);
  }, [addMsg, lang]);

  const setupRecognition = useCallback(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return null;
    const r = new SR();
    r.continuous = false;
    r.interimResults = true;
    r.lang = lang === 'ur' ? 'ur-PK' : 'en-US';

    r.onresult = (e) => {
      let final = '';
      let interim = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) final += e.results[i][0].transcript;
        else interim += e.results[i][0].transcript;
      }
      setInputVal(final || interim);
    };

    r.onend = () => {
      setListening(false);
      // Submit automatically if there's a value
      setInputVal(prev => {
        if (prev.trim()) {
          setTimeout(() => handleSend(prev.trim()), 100);
        }
        return prev;
      });
    };

    r.onerror = () => setListening(false);
    return r;
  // eslint-disable-next-line
  }, [lang]);

  const toggleMic = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { botSay(s.noVoice); return; }

    if (listening) {
      recognitionRef.current?.stop();
      setListening(false);
      return;
    }

    const r = setupRecognition();
    recognitionRef.current = r;
    r.start();
    setListening(true);
    setInputVal('');
  };

  const handleSend = async (value) => {
    const val = (value || inputVal).trim();
    if (!val || loading) return;
    setInputVal('');
    addMsg(val, 'user');

    if (step === 0) {
      setCurrentItem(ci => ({ ...ci, item: val }));
      setStep(1);
      botSay(s.askQty);
    } else if (step === 1) {
      setCurrentItem(ci => ({ ...ci, qtyRaw: val }));
      setStep(2);
      botSay(s.askPrice);
    } else if (step === 2) {
      setCurrentItem(ci => {
        const updated = { ...ci, priceRaw: val };
        // Parse via backend
        parseLine(updated);
        return updated;
      });
    }
    inputRef.current?.focus();
  };

  const parseLine = async (item) => {
    setLoading(true);
    try {
      const { data } = await axios.post('/api/parse', {
        item: item.item,
        qtyRaw: item.qtyRaw,
        priceRaw: item.priceRaw,
      });
      setBillItems(prev => [...prev, data]);
      const msg = s.added(data.item, data.quantity, data.unit, data.total);
      addMsg(msg, 'bot');
      speak(msg, lang);
      setStep(0);
      setCurrentItem({ item: '', qtyRaw: '', priceRaw: '' });
      setTimeout(() => botSay(s.greetItem), 700);
    } catch {
      addMsg(s.error, 'bot');
      speak(s.error, lang);
      setStep(2);
    } finally {
      setLoading(false);
    }
  };

  const removeItem = (index) => {
    setBillItems(prev => prev.filter((_, i) => i !== index));
  };

  const nextItem = () => {
    setStep(0);
    botSay(s.greetItem);
    inputRef.current?.focus();
  };

  const saveBill = async () => {
    if (!billItems.length || saving) return;
    setSaving(true);
    try {
      await axios.post('/api/bills', { items: billItems });
      setBillItems([]);
      setStep(0);
      setCurrentItem({ item: '', qtyRaw: '', priceRaw: '' });
      setMessages([]);
      const msg = s.saved;
      addMsg(msg, 'bot');
      speak(msg, lang);
      setTimeout(() => botSay(s.greetItem), 900);
      onBillSaved();
    } catch {
      addMsg('Error saving bill. Is the server running?', 'bot');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="bg-green-500 px-4 py-3 flex justify-between items-center">
        <div>
          <div className={`text-green-100 text-xs ${isUrdu ? 'font-urdu' : ''}`}>{s.currentBill}</div>
          <div className="text-white text-2xl font-bold">Rs. {Math.round(total).toLocaleString()}</div>
        </div>
        <div className="text-right">
          <div className={`text-green-100 text-xs ${isUrdu ? 'font-urdu' : ''}`}>{s.estProfit}</div>
          <div className="text-white text-2xl font-bold">Rs. {profit.toLocaleString()}</div>
        </div>
      </div>

      {/* Chat area */}
      <div className="p-4 min-h-[180px] max-h-[260px] overflow-y-auto flex flex-col gap-2 bg-gray-50">
        {messages.map(m => (
          <div
            key={m.id}
            className={`max-w-[82%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
              m.type === 'bot'
                ? 'bg-green-50 text-green-900 border border-green-100 self-start rounded-bl-sm font-medium'
                : 'bg-white border border-gray-200 self-end rounded-br-sm text-gray-800'
            } ${isUrdu ? 'font-urdu' : ''}`}
          >
            {m.text}
          </div>
        ))}
        {loading && (
          <div className="self-start bg-green-50 border border-green-100 px-4 py-3 rounded-2xl rounded-bl-sm flex gap-1 items-center">
            <span className="dot" /><span className="dot" /><span className="dot" />
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Input row */}
      <div className="px-4 pt-3 pb-2 border-t border-gray-100">
        <div className="flex gap-2 items-center">
          {/* Mic Button */}
          <button
            onClick={toggleMic}
            title={listening ? 'Stop' : 'Speak'}
            className={`w-11 h-11 rounded-full border flex items-center justify-center flex-shrink-0 transition-all ${
              listening
                ? 'bg-red-500 border-red-500 text-white mic-listening'
                : 'bg-white border-gray-200 text-gray-500 hover:border-green-400 hover:text-green-600'
            }`}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="9" y="2" width="6" height="12" rx="3"/>
              <path d="M5 10a7 7 0 0 0 14 0"/>
              <line x1="12" y1="19" x2="12" y2="22"/>
              <line x1="8" y1="22" x2="16" y2="22"/>
            </svg>
          </button>

          <input
            ref={inputRef}
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            placeholder={listening ? s.listening : s.typeHere}
            className={`flex-1 min-w-0 px-4 py-2.5 rounded-xl border text-sm outline-none transition-all ${
              listening
                ? 'border-red-300 bg-red-50 text-red-700'
                : 'border-gray-200 bg-gray-50 focus:border-green-400 focus:bg-white text-gray-800'
            } ${isUrdu ? 'font-urdu text-right' : ''}`}
          />

          <button
            onClick={() => handleSend()}
            disabled={!inputVal.trim() || loading}
            className="px-4 py-2.5 bg-green-500 text-white rounded-xl text-sm font-semibold disabled:opacity-40 hover:bg-green-600 transition-colors flex-shrink-0"
          >
            {s.send}
          </button>
        </div>
        <div className={`text-xs text-gray-400 mt-1.5 text-center ${isUrdu ? 'font-urdu' : ''}`}>
          {listening ? s.listening : s.tapMic}
        </div>
      </div>

      {/* Items list */}
      {billItems.length > 0 && (
        <div className="border-t border-gray-100">
          {billItems.map((item, i) => (
            <div key={i} className="flex items-center gap-3 px-4 py-3 border-b border-gray-50 last:border-0">
              <div className="flex-1 min-w-0">
                <div className={`font-semibold text-gray-900 text-sm ${isUrdu ? 'font-urdu' : ''}`}>{item.item}</div>
                <div className="text-xs text-gray-400">
                  {item.quantity} {item.unit} × Rs.{Math.round(item.price_per_unit)}
                </div>
              </div>
              <div className="font-bold text-green-700 text-sm">Rs. {Math.round(item.total)}</div>
              <button
                onClick={() => removeItem(i)}
                className="text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg px-2 py-1 text-xs transition-colors"
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Footer */}
      {billItems.length > 0 && (
        <div className="px-4 py-4 border-t border-gray-100 bg-gray-50">
          <div className="flex justify-between items-center mb-1">
            <span className={`text-sm text-gray-500 ${isUrdu ? 'font-urdu' : ''}`}>{s.total}</span>
            <span className="font-bold text-gray-900">Rs. {Math.round(total).toLocaleString()}</span>
          </div>
          <div className="flex justify-between items-center mb-4">
            <span className={`text-sm text-gray-500 ${isUrdu ? 'font-urdu' : ''}`}>{s.profit}</span>
            <span className="text-sm font-semibold text-green-600 bg-green-50 px-3 py-0.5 rounded-full">
              Rs. {profit.toLocaleString()}
            </span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={nextItem}
              className={`flex-1 py-3 border border-gray-200 rounded-xl text-sm font-semibold text-gray-700 hover:bg-gray-100 transition-colors ${isUrdu ? 'font-urdu' : ''}`}
            >
              {s.nextItem}
            </button>
            <button
              onClick={saveBill}
              disabled={saving}
              className={`flex-1 py-3 bg-green-500 text-white rounded-xl text-sm font-semibold hover:bg-green-600 disabled:opacity-50 transition-colors ${isUrdu ? 'font-urdu' : ''}`}
            >
              {saving ? '...' : s.saveBill}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
