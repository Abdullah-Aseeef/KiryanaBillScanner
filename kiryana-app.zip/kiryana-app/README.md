# Kiryana Assistant 🏪

A voice-guided sales and profit tracker for small kiryana store owners.
Built with MERN (MongoDB, Express, React, Node.js) + Tailwind CSS + Gemini AI.

---

## Prerequisites

- Node.js v18+
- MongoDB running locally (`mongod`) OR a free MongoDB Atlas URI
- A Gemini API key (free tier) from https://aistudio.google.com/app/apikey

---

## Setup (takes ~3 minutes)

### 1. Clone / extract this folder

### 2. Set up the server

```bash
cd server
npm install
cp .env.example .env
```

Open `server/.env` and fill in:
```
GEMINI_API_KEY=your_actual_gemini_key_here
MONGODB_URI=mongodb://localhost:27017/kiryana
PORT=5000
```

Start the server:
```bash
npm run dev
```

You should see:
```
✅ MongoDB connected
✅ Seeded sample daily sales data
✅ Server running on http://localhost:5000
```

### 3. Set up the client (in a new terminal)

```bash
cd client
npm install
npm start
```

The React app opens at http://localhost:3000

---

## How to use

1. **New Bill tab** — The assistant asks for item, quantity, price one at a time
2. **Tap the mic** to speak (works in Chrome/Edge) or just type
3. The app speaks every question out loud
4. Toggle **EN / اردو** in the top-right to switch language
5. Tap **Save Bill** to store the sale in MongoDB
6. **Dashboard tab** shows today's sales, profit, and bill history (live from DB)

### Supported voice inputs

| Step | Examples |
|------|---------|
| Item | "Aata", "Lipton chai", "Doodh" |
| Qty | "2 kilo", "1 pao", "aadha kilo", "pauna kilo", "dozen" |
| Price | "180 per kilo", "50 total", "1200 kilo ka" |

---

## API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/parse` | Sends item/qty/price to Gemini, returns parsed JSON |
| POST | `/api/bills` | Saves a completed bill to MongoDB |
| GET | `/api/dashboard` | Returns today's bills + stats |
| DELETE | `/api/bills/:id` | Delete a bill |

---

## Deployment (optional)

- **Backend**: Deploy `server/` to Railway or Render. Set env vars in their dashboard.
- **Frontend**: Deploy `client/` to Vercel. Set `REACT_APP_API_URL` if backend is not on same domain, and update the proxy in `package.json`.
